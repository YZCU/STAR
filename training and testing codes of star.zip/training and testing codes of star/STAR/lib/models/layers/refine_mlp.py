import torch
import torch.nn as nn
import torch.nn.functional as F
import collections.abc
from itertools import repeat
def _ntuple(n):
    return lambda x: tuple(x if isinstance(x, collections.abc.Iterable) and not isinstance(x, str) else repeat(x, n))
to_2tuple = _ntuple(2)
class RefineMLP(nn.Module):
    def __init__(
            self,
            in_features,
            hidden_features=None,
            out_features=None,
            act_layer=nn.GELU,
            norm_layer=None,
            bias=True,
            drop=0.0,
    ):
        super().__init__()
        hidden_features = hidden_features or in_features
        self.window_scale = 4
        out_features = out_features or in_features
        bias = to_2tuple(bias)
        drop_probs = to_2tuple(drop)
        self.fc1 = nn.Linear(in_features, hidden_features, bias=bias[0])
        self.act = act_layer()
        self.drop1 = nn.Dropout(drop_probs[0])
        self.norm = norm_layer(hidden_features) if norm_layer is not None else nn.Identity()
        self.fc2 = nn.Linear(hidden_features, out_features, bias=bias[1])
        self.drop2 = nn.Dropout(drop_probs[1])
        self.refine_alpha = nn.Parameter(torch.ones(1, in_features, 1))
        self.refine_belt = nn.Parameter(torch.zeros(1, in_features, 1))
        self.refine_dw_conv = nn.Conv1d(in_features, in_features, kernel_size=3, padding=1, groups=in_features)
        self.refine_pw_conv = nn.Conv1d(in_features, in_features, kernel_size=1)
    def forward(self, x):
        bs, n, c = x.size()
        x_orig = x.transpose(1, 2)
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop1(x)
        x = self.norm(x)
        x = self.fc2(x)
        x_mlp = self.drop2(x)
        x_avg = F.adaptive_avg_pool1d(x_orig, n // self.window_scale)
        x_reshaped = x_orig.view(x_orig.size(0), x_orig.size(1), n // self.window_scale, self.window_scale)
        x_var = torch.var(x_reshaped, dim=-1)
        xx = self.act(self.refine_dw_conv(x_avg * self.refine_alpha + x_var * self.refine_belt))
        xx = x_orig * F.interpolate(xx, size=x_orig.size(2), mode='nearest')
        xx = self.refine_pw_conv(xx).transpose(1, 2)
        return x_mlp + xx
def main():
    batch_size, n_tokens, dim = 8, 320, 512
    model = RefineMLP(in_features=dim, hidden_features=dim * 4, act_layer=nn.GELU, drop=0.1)
    x = torch.randn(batch_size, n_tokens, dim)
    model.train()
    output = model(x)
    print(f"Output shape: {output.shape}")
if __name__ == "__main__":
    main()
