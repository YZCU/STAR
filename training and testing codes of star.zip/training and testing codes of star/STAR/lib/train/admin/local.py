class EnvironmentSettings:
    def __init__(self):
        self.workspace_dir = ''
        self.tensorboard_dir = ''

        self.satsot_train_dir = r'I:\0satsot_train_ziji'
        self.viso_val_dir = r'I:\0viso_ICLR22_ziji'
        self.satsot_val_dir = r'I:\0satsot_train_ziji'

        # self.satsot_train_dir = r'I:\satsot_train_dir'
        # self.viso_val_dir = r'I:\viso_val_dir'
        # self.satsot_val_dir = r'I:\satsot_val_dir'
