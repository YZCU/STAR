import numpy as np
import multiprocessing
import os
import sys
from itertools import product
from collections import OrderedDict
from lib.test.evaluation import Sequence, Tracker
import torch
def _save_tracker_output(seq: Sequence, tracker: Tracker, output: dict):
    if not os.path.exists(tracker.results_dir):
        print("create tracking result dir:", tracker.results_dir)
        os.makedirs(tracker.results_dir)
    base_results_path = os.path.join(tracker.results_dir, seq.name)
    def save_bb(file, data):
        tracked_bb = np.array(data).astype(float)
        np.savetxt(file, tracked_bb, delimiter=',', fmt='%f')
    def save_time(file, data):
        exec_times = np.array(data).astype(float)
        np.savetxt(file, exec_times, delimiter='\t', fmt='%f')
    for key, data in output.items():
        if not data:
            continue
        if key == 'target_bbox':
            bbox_file = '{}.txt'.format(base_results_path)
            save_bb(bbox_file, data)
        elif key == 'time':
            timings_file = '{}.txt'.format(os.path.join(tracker.results_dir, 'fps', seq.name))
def run_sequence(seq: Sequence, tracker: Tracker, debug=False, num_gpu=8):
    try:
        worker_name = multiprocessing.current_process().name
        worker_id = int(worker_name[worker_name.find('-') + 1:]) - 1
        gpu_id = worker_id % num_gpu
        torch.cuda.set_device(gpu_id)
    except:
        pass
    def _results_exist():
        if seq.object_ids is None:
            bbox_file = '{}/{}.txt'.format(tracker.results_dir, seq.name)
            return os.path.isfile(bbox_file)
        else:
            bbox_files = ['{}/{}_{}.txt'.format(tracker.results_dir, seq.name, obj_id) for obj_id in seq.object_ids]
            missing = [not os.path.isfile(f) for f in bbox_files]
            return sum(missing) == 0
    if _results_exist():
        print('FPS: {}'.format(-1))
        return
    print('Tracker: {} {} {} ,  Sequence: {}'.format(tracker.name, tracker.parameter_name, tracker.run_id, seq.name))
    if debug:
        output = tracker.run_sequence(seq, debug=debug)
    else:
        try:
            output = tracker.run_sequence(seq, debug=debug)
        except Exception as e:
            print(e)
            return
    sys.stdout.flush()
    if isinstance(output['time'][0], (dict, OrderedDict)):
        exec_time = sum([sum(times.values()) for times in output['time']])
        num_frames = len(output['time'])
    else:
        exec_time = sum(output['time'])
        num_frames = len(output['time'])
    print('FPS: {}'.format(num_frames / exec_time))
    _save_tracker_output(seq, tracker, output)
def run_dataset(dataset, trackers, debug=False, threads=0, num_gpus=8):
    multiprocessing.set_start_method('spawn', force=True)
    print('Evaluating {:4d} trackers on {:5d} sequences'.format(len(trackers), len(dataset)))
    multiprocessing.set_start_method('spawn', force=True)
    if threads == 0:
        mode = 'sequential'
    else:
        mode = 'parallel'
    if mode == 'sequential':
        for seq in dataset:
            for tracker_info in trackers:
                run_sequence(seq, tracker_info, debug=debug)
    elif mode == 'parallel':
        param_list = [(seq, tracker_info, debug, num_gpus) for seq, tracker_info in product(dataset, trackers)]
        with multiprocessing.Pool(processes=threads) as pool:
            pool.starmap(run_sequence, param_list)
    print('Done')
