from collections import namedtuple
import importlib
from lib.test.evaluation.data import SequenceList
DatasetInfo = namedtuple('DatasetInfo', ['module', 'class_name', 'kwargs'])
pt = "lib.test.evaluation.%sdataset"
dataset_dict = dict(
    satsot=DatasetInfo(module=pt % "satsot", class_name="satsotDataset", kwargs=dict()),
    sv248s=DatasetInfo(module=pt % "sv248s", class_name="sv248sDataset", kwargs=dict()),
    ootb=DatasetInfo(module=pt % "ootb", class_name="ootbDataset", kwargs=dict()),
)
def load_dataset(name: str):
    name = name.lower()
    dset_info = dataset_dict.get(name)
    if dset_info is None:
        raise ValueError('Unknown dataset \'%s\'' % name)
    m = importlib.import_module(dset_info.module)
    dataset = getattr(m, dset_info.class_name)(**dset_info.kwargs)
    return dataset.get_sequence_list()
def get_dataset(*args):
    dset = SequenceList()
    for name in args:
        dset.extend(load_dataset(name))
    return dset
