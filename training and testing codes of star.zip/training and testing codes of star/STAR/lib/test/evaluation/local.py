from lib.test.evaluation.environment import EnvSettings
import os
current_path = os.getcwd()
target_path = os.path.dirname(current_path)
def local_env_settings():
    settings = EnvSettings()
    base_dir = target_path
    settings.satsot_path = r'I:\satsot_path'
    settings.sv248s_path = r'I:\sv248s_path'
    settings.ootb_path = r'I:\ootb_path'
    settings.prj_dir = settings.save_dir = base_dir
    settings.results_path = fr'{base_dir}\output\results'
    return settings
