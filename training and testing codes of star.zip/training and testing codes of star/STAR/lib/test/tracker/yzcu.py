import math
from lib.models.yzcu import build_yzcu
from lib.test.tracker.basetracker import BaseTracker
import torch
from lib.test.tracker.vis_utils import gen_visualization
from lib.test.utils.hann import hann2d
from lib.train.data.processing_utils import sample_target
import cv2
import os
from lib.test.tracker.data_utils import Preprocessor
from lib.utils.box_ops import clip_box
from lib.utils.box_ops import new_clip_box
from lib.utils.ce_utils import generate_mask_cond
import numpy as np
no_process_frame_num = 30
class MotionModel:
    def __init__(self):
        self.trajectory_length = 1
        self.history_x, self.history_y, self.history_factor = [], [], []
    def calculate_apce(self, response_map):
        R_max, R_min = np.max(response_map), np.min(response_map)
        return R_max
    def compute_cur_his_confidence(self, response_map):
        R_max = np.max(response_map)
        peak_idx = np.unravel_index(np.argmax(response_map), response_map.shape)
        side_lobe = np.delete(response_map.flatten(), np.ravel_multi_index(peak_idx, response_map.shape))
        R_mean, R_std = np.mean(side_lobe), np.std(side_lobe)
        psr = 0 if R_std == 0 else (R_max - R_mean) / R_std
        cur_confid = psr * R_max
        his_reliable_confid = np.mean(self.history_factor) if self.history_factor else cur_confid
        return cur_confid, his_reliable_confid
    def fit(self, data, degree=2):
        if len(data) < 2:
            return data[-1] if data else 0
        return np.poly1d(np.polyfit(range(len(data)), data, degree))(len(data))
    def update_pos(self, new_x, new_y):
        self.history_x.append(new_x)
        self.history_y.append(new_y)
        if len(self.history_x) > self.trajectory_length:
            self.history_x.pop(0)
            self.history_y.pop(0)
    def update_confidence(self, cur_confid):
        if cur_confid is not None:
            self.history_factor.append(cur_confid)
    def predict(self):
        return self.fit(self.history_x), self.fit(self.history_y)
    def get_corrected_pos(self, frame_id, response_map, occlusion_threshold=0.0, trajectory_length=10000):
        self.trajectory_length = trajectory_length
        cur_confid, his_reliable_confid = self.compute_cur_his_confidence(response_map)
        if frame_id < no_process_frame_num:
            return cur_confid, None, None, False
        if cur_confid / his_reliable_confid < occlusion_threshold:
            predicted_x, predicted_y = self.predict()
            return None, predicted_x, predicted_y, True
        return cur_confid, None, None, False
class yzcu(BaseTracker):
    def __init__(self, params, dataset_name):
        super(yzcu, self).__init__(params)
        network = build_yzcu(params.cfg, training=False)
        network.load_state_dict(torch.load(self.params.checkpoint, map_location='cpu')['net'], strict=True)
        self.cfg = params.cfg
        self.network = network.cuda()
        self.network.eval()
        self.preprocessor = Preprocessor()
        self.state = None
        self.feat_sz = self.cfg.TEST.SEARCH_SIZE // self.cfg.MODEL.BACKBONE.STRIDE
        self.output_window = hann2d(torch.tensor([self.feat_sz, self.feat_sz]).long(), centered=True).cuda()
        self.debug = params.debug
        self.use_visdom = params.debug
        self.frame_id = 0
        self.save_all_boxes = params.save_all_boxes
        self.z_dict1 = {}
        self.tgt_all = []
        self.init_box = []
        self.motion_model = None
    def initialize(self, image, info: dict):
        x1, y1, w, h = info['init_bbox']
        min_w, min_h = 5.0, 5.0
        if w < min_w:
            w = max(w, min_w)
            x1 -= (min_w - w) / 2
        if h < min_h:
            h = max(h, min_h)
            y1 -= (min_h - h) / 2
        self.init_box = info['init_bbox'] = [x1, y1, w, h]
        self.motion_model = MotionModel()
        self.motion_model.update_pos(x1, y1)
        z_patch_arr, resize_factor, z_amask_arr = sample_target(image, info['init_bbox'], self.params.template_factor,
                                                                output_sz=self.params.template_size)
        self.z_patch_arr = z_patch_arr
        template = self.preprocessor.process(z_patch_arr, z_amask_arr)
        with torch.no_grad():
            self.z_dict1 = template
        self.state = info['init_bbox']
        self.frame_id = 0
        if self.save_all_boxes:
            all_boxes_save = info['init_bbox'] * self.cfg.MODEL.NUM_OBJECT_QUERIES
            return {"all_boxes": all_boxes_save}
        self.tgt_all = []
    def track(self, image, info: dict = None, seq_name=[]):
        H, W, _ = image.shape
        self.frame_id += 1
        x_patch_arr, resize_factor, x_amask_arr = sample_target(image, self.state, self.params.search_factor,
                                                                output_sz=self.params.search_size)
        search = self.preprocessor.process(x_patch_arr, x_amask_arr)
        with torch.no_grad():
            x_dict = search
            out_dict = self.network.forward(template=self.z_dict1.tensors, search=x_dict.tensors, training=False,
                                            tgt_pre=self.tgt_all)
            self.tgt_all = out_dict['tgt']
        pred_score_map = out_dict['score_map']
        response = self.output_window * pred_score_map
        respons_map = response.cpu().numpy().reshape(16, 16)
        pred_boxes = self.network.box_head.cal_bbox(response, out_dict['size_map'], out_dict['offset_map'])
        pred_boxes = pred_boxes.view(-1, 4)
        pred_box = (pred_boxes.mean(dim=0) * self.params.search_size / resize_factor).tolist()
        self.state = new_clip_box(self.map_box_back(pred_box, resize_factor), H, W, min_size=5, init_box=self.init_box,
                                  max_margin_factor=self.params.cfg.TEST.MAX_MARGIN_FACTOR)
        cur_confid, correct_x, correct_y, is_abnormal = self.motion_model.get_corrected_pos(self.frame_id, respons_map,
                                                                                            occlusion_threshold=self.params.occlusion_threshold,
                                                                                            trajectory_length=self.params.cfg.TEST.TRAJECTORY_LENGTH)
        if is_abnormal:
            self.state = [correct_x, correct_y, self.state[2], self.state[3]]
        self.motion_model.update_pos(*self.state[:2])
        self.motion_model.update_confidence(cur_confid)
        if self.save_all_boxes:
            all_boxes = self.map_box_back_batch(pred_boxes * self.params.search_size / resize_factor, resize_factor)
            all_boxes_save = all_boxes.view(-1).tolist()
            return {"target_bbox": self.state,
                    "all_boxes": all_boxes_save}
        else:
            return {"target_bbox": self.state}
    def map_box_back(self, pred_box: list, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return [cx_real - 0.5 * w, cy_real - 0.5 * h, w, h]
    def map_box_back_batch(self, pred_box: torch.Tensor, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box.unbind(-1)
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return torch.stack([cx_real - 0.5 * w, cy_real - 0.5 * h, w, h], dim=-1)
    def add_hook(self):
        conv_features, enc_attn_weights, dec_attn_weights = [], [], []
        for i in range(12):
            self.network.backbone.blocks[i].attn.register_forward_hook(
                lambda self, input, output: enc_attn_weights.append(output[1])
            )
        self.enc_attn_weights = enc_attn_weights
def get_tracker_class():
    return yzcu
